
<template>
<!-- 购物列表 -->
    <div>
        <span><img src="../../public/images/checked.png" alt=""></span>
    </div>
</template>
<script>
export default {
    
}

</script>
<style scoped>
    
</style>